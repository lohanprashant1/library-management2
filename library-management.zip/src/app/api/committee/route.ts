import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/committee
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const department = searchParams.get('department') || '';
    const role = searchParams.get('role') || '';
    const isActive = searchParams.get('isActive');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { designation: { contains: search } },
        { department: { contains: search } },
        { email: { contains: search } },
      ];
    }
    if (department) where.department = department;
    if (role) where.role = role;
    if (isActive !== null && isActive !== undefined && isActive !== '') {
      where.isActive = isActive === 'true';
    }

    const [items, total] = await Promise.all([
      db.committee.findMany({
        where,
        orderBy: { sortOrder: 'asc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.committee.count({ where }),
    ]);

    return NextResponse.json({ items, total, page, limit });
  } catch (error) {
    console.error('Committee GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch committee members' }, { status: 500 });
  }
}

// POST /api/committee
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const committee = await db.committee.create({
      data: {
        name: body.name,
        designation: body.designation,
        department: body.department,
        role: body.role,
        email: body.email,
        phone: body.phone,
        photo: body.photo,
        sortOrder: body.sortOrder || 0,
        isActive: body.isActive ?? true,
      },
    });
    return NextResponse.json(committee, { status: 201 });
  } catch (error) {
    console.error('Committee POST error:', error);
    return NextResponse.json({ error: 'Failed to create committee member' }, { status: 500 });
  }
}

// PUT /api/committee
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'Committee ID is required' }, { status: 400 });
    }

    const existing = await db.committee.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Committee member not found' }, { status: 404 });
    }

    const committee = await db.committee.update({
      where: { id },
      data: {
        name: data.name ?? undefined,
        designation: data.designation ?? undefined,
        department: data.department ?? undefined,
        role: data.role ?? undefined,
        email: data.email ?? undefined,
        phone: data.phone ?? undefined,
        photo: data.photo ?? undefined,
        sortOrder: data.sortOrder ?? undefined,
        isActive: data.isActive ?? undefined,
      },
    });
    return NextResponse.json(committee);
  } catch (error) {
    console.error('Committee PUT error:', error);
    return NextResponse.json({ error: 'Failed to update committee member' }, { status: 500 });
  }
}

// DELETE /api/committee?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'Committee ID is required' }, { status: 400 });
    }

    await db.committee.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Committee DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete committee member' }, { status: 500 });
  }
}
