import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/faculty-publications
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const department = searchParams.get('department') || '';
    const pubType = searchParams.get('pubType') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { author: { contains: search } },
        { journal: { contains: search } },
        { abstract: { contains: search } },
      ];
    }
    if (department) where.department = department;
    if (pubType) where.pubType = pubType;

    const [items, total] = await Promise.all([
      db.facultyPublication.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.facultyPublication.count({ where }),
    ]);

    return NextResponse.json({ items, total, page, limit });
  } catch (error) {
    console.error('Faculty Publications GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch faculty publications' }, { status: 500 });
  }
}

// POST /api/faculty-publications
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const facultyPublication = await db.facultyPublication.create({
      data: {
        title: body.title,
        author: body.author,
        department: body.department,
        journal: body.journal,
        year: body.year,
        doi: body.doi,
        abstract: body.abstract,
        pubType: body.pubType || 'Article',
        url: body.url,
      },
    });
    return NextResponse.json(facultyPublication, { status: 201 });
  } catch (error) {
    console.error('Faculty Publications POST error:', error);
    return NextResponse.json({ error: 'Failed to create faculty publication' }, { status: 500 });
  }
}

// PUT /api/faculty-publications
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'Publication ID is required' }, { status: 400 });
    }

    const existing = await db.facultyPublication.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Publication not found' }, { status: 404 });
    }

    const facultyPublication = await db.facultyPublication.update({
      where: { id },
      data: {
        title: data.title ?? undefined,
        author: data.author ?? undefined,
        department: data.department ?? undefined,
        journal: data.journal ?? undefined,
        year: data.year ?? undefined,
        doi: data.doi ?? undefined,
        abstract: data.abstract ?? undefined,
        pubType: data.pubType ?? undefined,
        url: data.url ?? undefined,
      },
    });
    return NextResponse.json(facultyPublication);
  } catch (error) {
    console.error('Faculty Publications PUT error:', error);
    return NextResponse.json({ error: 'Failed to update faculty publication' }, { status: 500 });
  }
}

// DELETE /api/faculty-publications?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'Publication ID is required' }, { status: 400 });
    }

    await db.facultyPublication.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Faculty Publications DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete faculty publication' }, { status: 500 });
  }
}
