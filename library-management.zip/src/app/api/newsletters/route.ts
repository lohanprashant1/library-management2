import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/newsletters
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const issue = searchParams.get('issue') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
      ];
    }
    if (issue) where.issue = issue;

    const [items, total] = await Promise.all([
      db.newsletter.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.newsletter.count({ where }),
    ]);

    return NextResponse.json({ items, total, page, limit });
  } catch (error) {
    console.error('Newsletters GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch newsletters' }, { status: 500 });
  }
}

// POST /api/newsletters
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const newsletter = await db.newsletter.create({
      data: {
        title: body.title,
        description: body.description,
        fileUrl: body.fileUrl,
        issue: body.issue,
        date: body.date ? new Date(body.date) : undefined,
      },
    });
    return NextResponse.json(newsletter, { status: 201 });
  } catch (error) {
    console.error('Newsletters POST error:', error);
    return NextResponse.json({ error: 'Failed to create newsletter' }, { status: 500 });
  }
}

// PUT /api/newsletters
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'Newsletter ID is required' }, { status: 400 });
    }

    const existing = await db.newsletter.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Newsletter not found' }, { status: 404 });
    }

    const newsletter = await db.newsletter.update({
      where: { id },
      data: {
        title: data.title ?? undefined,
        description: data.description ?? undefined,
        fileUrl: data.fileUrl ?? undefined,
        issue: data.issue ?? undefined,
        date: data.date ? new Date(data.date) : undefined,
      },
    });
    return NextResponse.json(newsletter);
  } catch (error) {
    console.error('Newsletters PUT error:', error);
    return NextResponse.json({ error: 'Failed to update newsletter' }, { status: 500 });
  }
}

// DELETE /api/newsletters?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'Newsletter ID is required' }, { status: 400 });
    }

    await db.newsletter.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Newsletters DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete newsletter' }, { status: 500 });
  }
}
