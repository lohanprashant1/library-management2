import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/notices
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const type = searchParams.get('type') || '';
    const priority = searchParams.get('priority') || '';
    const isActive = searchParams.get('isActive');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { content: { contains: search } },
      ];
    }
    if (type) where.type = type;
    if (priority) where.priority = priority;
    if (isActive !== null && isActive !== undefined && isActive !== '') {
      where.isActive = isActive === 'true';
    }

    const [items, total] = await Promise.all([
      db.notice.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.notice.count({ where }),
    ]);

    return NextResponse.json({ items, total, page, limit });
  } catch (error) {
    console.error('Notices GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch notices' }, { status: 500 });
  }
}

// POST /api/notices
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const notice = await db.notice.create({
      data: {
        title: body.title,
        content: body.content,
        type: body.type || 'General',
        priority: body.priority || 'Normal',
        publishDate: body.publishDate ? new Date(body.publishDate) : undefined,
        expiryDate: body.expiryDate ? new Date(body.expiryDate) : undefined,
        isActive: body.isActive ?? true,
      },
    });
    return NextResponse.json(notice, { status: 201 });
  } catch (error) {
    console.error('Notices POST error:', error);
    return NextResponse.json({ error: 'Failed to create notice' }, { status: 500 });
  }
}

// PUT /api/notices
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'Notice ID is required' }, { status: 400 });
    }

    const existing = await db.notice.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Notice not found' }, { status: 404 });
    }

    const notice = await db.notice.update({
      where: { id },
      data: {
        title: data.title ?? undefined,
        content: data.content ?? undefined,
        type: data.type ?? undefined,
        priority: data.priority ?? undefined,
        publishDate: data.publishDate ? new Date(data.publishDate) : undefined,
        expiryDate: data.expiryDate ? new Date(data.expiryDate) : undefined,
        isActive: data.isActive ?? undefined,
      },
    });
    return NextResponse.json(notice);
  } catch (error) {
    console.error('Notices PUT error:', error);
    return NextResponse.json({ error: 'Failed to update notice' }, { status: 500 });
  }
}

// DELETE /api/notices?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'Notice ID is required' }, { status: 400 });
    }

    await db.notice.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Notices DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete notice' }, { status: 500 });
  }
}
