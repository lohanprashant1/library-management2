import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/library-rules
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const category = searchParams.get('category') || '';
    const isActive = searchParams.get('isActive');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { content: { contains: search } },
      ];
    }
    if (category) where.category = category;
    if (isActive !== null && isActive !== undefined && isActive !== '') {
      where.isActive = isActive === 'true';
    }

    const [items, total] = await Promise.all([
      db.libraryRule.findMany({
        where,
        orderBy: { sortOrder: 'asc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.libraryRule.count({ where }),
    ]);

    return NextResponse.json({ items, total, page, limit });
  } catch (error) {
    console.error('Library Rules GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch library rules' }, { status: 500 });
  }
}

// POST /api/library-rules
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const libraryRule = await db.libraryRule.create({
      data: {
        title: body.title,
        content: body.content,
        category: body.category || 'General',
        sortOrder: body.sortOrder || 0,
        isActive: body.isActive ?? true,
      },
    });
    return NextResponse.json(libraryRule, { status: 201 });
  } catch (error) {
    console.error('Library Rules POST error:', error);
    return NextResponse.json({ error: 'Failed to create library rule' }, { status: 500 });
  }
}

// PUT /api/library-rules
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'Library Rule ID is required' }, { status: 400 });
    }

    const existing = await db.libraryRule.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Library Rule not found' }, { status: 404 });
    }

    const libraryRule = await db.libraryRule.update({
      where: { id },
      data: {
        title: data.title ?? undefined,
        content: data.content ?? undefined,
        category: data.category ?? undefined,
        sortOrder: data.sortOrder ?? undefined,
        isActive: data.isActive ?? undefined,
      },
    });
    return NextResponse.json(libraryRule);
  } catch (error) {
    console.error('Library Rules PUT error:', error);
    return NextResponse.json({ error: 'Failed to update library rule' }, { status: 500 });
  }
}

// DELETE /api/library-rules?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'Library Rule ID is required' }, { status: 400 });
    }

    await db.libraryRule.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Library Rules DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete library rule' }, { status: 500 });
  }
}
