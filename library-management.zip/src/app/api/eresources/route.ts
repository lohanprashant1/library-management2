import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/eresources
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const category = searchParams.get('category') || '';
    const accessType = searchParams.get('accessType') || '';
    const isActive = searchParams.get('isActive');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { description: { contains: search } },
        { publisher: { contains: search } },
      ];
    }
    if (category) where.category = category;
    if (accessType) where.accessType = accessType;
    if (isActive !== null && isActive !== undefined && isActive !== '') {
      where.isActive = isActive === 'true';
    }

    const [items, total] = await Promise.all([
      db.eResource.findMany({
        where,
        orderBy: { sortOrder: 'asc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.eResource.count({ where }),
    ]);

    return NextResponse.json({ items, total, page, limit });
  } catch (error) {
    console.error('E-Resources GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch e-resources' }, { status: 500 });
  }
}

// POST /api/eresources
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const eResource = await db.eResource.create({
      data: {
        name: body.name,
        url: body.url,
        description: body.description,
        category: body.category,
        accessType: body.accessType || 'Free',
        publisher: body.publisher,
        isActive: body.isActive ?? true,
        sortOrder: body.sortOrder || 0,
      },
    });
    return NextResponse.json(eResource, { status: 201 });
  } catch (error) {
    console.error('E-Resources POST error:', error);
    return NextResponse.json({ error: 'Failed to create e-resource' }, { status: 500 });
  }
}

// PUT /api/eresources
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'E-Resource ID is required' }, { status: 400 });
    }

    const existing = await db.eResource.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'E-Resource not found' }, { status: 404 });
    }

    const eResource = await db.eResource.update({
      where: { id },
      data: {
        name: data.name ?? undefined,
        url: data.url ?? undefined,
        description: data.description ?? undefined,
        category: data.category ?? undefined,
        accessType: data.accessType ?? undefined,
        publisher: data.publisher ?? undefined,
        isActive: data.isActive ?? undefined,
        sortOrder: data.sortOrder ?? undefined,
      },
    });
    return NextResponse.json(eResource);
  } catch (error) {
    console.error('E-Resources PUT error:', error);
    return NextResponse.json({ error: 'Failed to update e-resource' }, { status: 500 });
  }
}

// DELETE /api/eresources?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'E-Resource ID is required' }, { status: 400 });
    }

    await db.eResource.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('E-Resources DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete e-resource' }, { status: 500 });
  }
}
