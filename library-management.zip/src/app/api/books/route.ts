import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/books
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const categoryId = searchParams.get('categoryId') || '';
    const authorId = searchParams.get('authorId') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { isbn: { contains: search } },
        { publisher: { contains: search } },
        { description: { contains: search } },
        { author: { name: { contains: search } } },
        { category: { name: { contains: search } } },
      ];
    }
    if (categoryId) where.categoryId = categoryId;
    if (authorId) where.authorId = authorId;

    const [books, total] = await Promise.all([
      db.book.findMany({
        where,
        include: { category: true, author: true },
        orderBy: { addedAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.book.count({ where }),
    ]);

    return NextResponse.json({ books, total, page, limit });
  } catch (error) {
    console.error('Books GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch books' }, { status: 500 });
  }
}

// POST /api/books
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const book = await db.book.create({
      data: {
        title: body.title,
        isbn: body.isbn || '',
        description: body.description || '',
        publisher: body.publisher || '',
        publishYear: body.publishYear || 2024,
        totalCopies: body.totalCopies || 1,
        availableCopies: body.totalCopies || 1,
        categoryId: body.categoryId,
        authorId: body.authorId,
        coverImage: body.coverImage || '',
        shelfLocation: body.shelfLocation || '',
      },
      include: { category: true, author: true },
    });
    return NextResponse.json(book, { status: 201 });
  } catch (error) {
    console.error('Books POST error:', error);
    return NextResponse.json({ error: 'Failed to create book' }, { status: 500 });
  }
}

// PUT /api/books
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'Book ID is required' }, { status: 400 });
    }

    const existing = await db.book.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Book not found' }, { status: 404 });
    }

    const book = await db.book.update({
      where: { id },
      data: {
        title: data.title ?? undefined,
        isbn: data.isbn ?? undefined,
        description: data.description ?? undefined,
        publisher: data.publisher ?? undefined,
        publishYear: data.publishYear ?? undefined,
        totalCopies: data.totalCopies ?? undefined,
        availableCopies: data.availableCopies ?? undefined,
        categoryId: data.categoryId ?? undefined,
        authorId: data.authorId ?? undefined,
        coverImage: data.coverImage ?? undefined,
        shelfLocation: data.shelfLocation ?? undefined,
      },
      include: { category: true, author: true },
    });
    return NextResponse.json(book);
  } catch (error) {
    console.error('Books PUT error:', error);
    return NextResponse.json({ error: 'Failed to update book' }, { status: 500 });
  }
}

// DELETE /api/books?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'Book ID is required' }, { status: 400 });
    }

    const activeTransactions = await db.transaction.count({
      where: { bookId: id, status: 'Issued' },
    });

    if (activeTransactions > 0) {
      return NextResponse.json(
        { error: 'Cannot delete book with active transactions. Return all copies first.' },
        { status: 400 }
      );
    }

    await db.book.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Books DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete book' }, { status: 500 });
  }
}
