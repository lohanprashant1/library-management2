import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/suggestions
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const status = searchParams.get('status') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { author: { contains: search } },
        { name: { contains: search } },
        { reason: { contains: search } },
      ];
    }
    if (status) where.status = status;

    const [items, total] = await Promise.all([
      db.suggestion.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.suggestion.count({ where }),
    ]);

    return NextResponse.json({ items, total, page, limit });
  } catch (error) {
    console.error('Suggestions GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch suggestions' }, { status: 500 });
  }
}

// POST /api/suggestions
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const suggestion = await db.suggestion.create({
      data: {
        title: body.title,
        author: body.author || '',
        reason: body.reason || '',
        name: body.name,
        email: body.email,
        phone: body.phone || '',
        status: body.status || 'Pending',
      },
    });
    return NextResponse.json(suggestion, { status: 201 });
  } catch (error) {
    console.error('Suggestions POST error:', error);
    return NextResponse.json({ error: 'Failed to create suggestion' }, { status: 500 });
  }
}

// PUT /api/suggestions
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'Suggestion ID is required' }, { status: 400 });
    }

    const existing = await db.suggestion.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Suggestion not found' }, { status: 404 });
    }

    const suggestion = await db.suggestion.update({
      where: { id },
      data: {
        title: data.title ?? undefined,
        author: data.author ?? undefined,
        reason: data.reason ?? undefined,
        name: data.name ?? undefined,
        email: data.email ?? undefined,
        phone: data.phone ?? undefined,
        status: data.status ?? undefined,
      },
    });
    return NextResponse.json(suggestion);
  } catch (error) {
    console.error('Suggestions PUT error:', error);
    return NextResponse.json({ error: 'Failed to update suggestion' }, { status: 500 });
  }
}

// DELETE /api/suggestions?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'Suggestion ID is required' }, { status: 400 });
    }

    await db.suggestion.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Suggestions DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete suggestion' }, { status: 500 });
  }
}
