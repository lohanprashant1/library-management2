import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/research-guides
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const category = searchParams.get('category') || '';
    const isActive = searchParams.get('isActive');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
        { content: { contains: search } },
        { author: { contains: search } },
      ];
    }
    if (category) where.category = category;
    if (isActive !== null && isActive !== undefined && isActive !== '') {
      where.isActive = isActive === 'true';
    }

    const [items, total] = await Promise.all([
      db.researchGuide.findMany({
        where,
        orderBy: { sortOrder: 'asc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.researchGuide.count({ where }),
    ]);

    return NextResponse.json({ items, total, page, limit });
  } catch (error) {
    console.error('Research Guides GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch research guides' }, { status: 500 });
  }
}

// POST /api/research-guides
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const researchGuide = await db.researchGuide.create({
      data: {
        title: body.title,
        description: body.description,
        category: body.category,
        content: body.content,
        author: body.author,
        fileUrl: body.fileUrl,
        sortOrder: body.sortOrder || 0,
        isActive: body.isActive ?? true,
      },
    });
    return NextResponse.json(researchGuide, { status: 201 });
  } catch (error) {
    console.error('Research Guides POST error:', error);
    return NextResponse.json({ error: 'Failed to create research guide' }, { status: 500 });
  }
}

// PUT /api/research-guides
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'Research Guide ID is required' }, { status: 400 });
    }

    const existing = await db.researchGuide.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Research Guide not found' }, { status: 404 });
    }

    const researchGuide = await db.researchGuide.update({
      where: { id },
      data: {
        title: data.title ?? undefined,
        description: data.description ?? undefined,
        category: data.category ?? undefined,
        content: data.content ?? undefined,
        author: data.author ?? undefined,
        fileUrl: data.fileUrl ?? undefined,
        sortOrder: data.sortOrder ?? undefined,
        isActive: data.isActive ?? undefined,
      },
    });
    return NextResponse.json(researchGuide);
  } catch (error) {
    console.error('Research Guides PUT error:', error);
    return NextResponse.json({ error: 'Failed to update research guide' }, { status: 500 });
  }
}

// DELETE /api/research-guides?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'Research Guide ID is required' }, { status: 400 });
    }

    await db.researchGuide.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Research Guides DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete research guide' }, { status: 500 });
  }
}
