import { db } from '@/lib/db';
import { createHash } from 'crypto';
import { NextRequest, NextResponse } from 'next/server';

function hashPassword(password: string): string {
  return createHash('sha256').update(password).digest('hex');
}

// GET /api/settings
export async function GET() {
  try {
    let settings = await db.settings.findUnique({ where: { id: 'default' } });
    if (!settings) {
      settings = await db.settings.create({
        data: {
          id: 'default',
          libraryName: 'City Central Library',
        },
      });
    }
    return NextResponse.json(settings);
  } catch (error) {
    console.error('Settings GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch settings' }, { status: 500 });
  }
}

// PUT /api/settings
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const settings = await db.settings.upsert({
      where: { id: 'default' },
      update: {
        libraryName: body.libraryName ?? undefined,
        address: body.address ?? undefined,
        phone: body.phone ?? undefined,
        email: body.email ?? undefined,
        aboutText: body.aboutText ?? undefined,
        maxBooksPerMember: body.maxBooksPerMember ?? undefined,
        maxLoanDays: body.maxLoanDays ?? undefined,
        finePerDay: body.finePerDay ?? undefined,
        openingHours: body.openingHours ?? undefined,
        membershipFee: body.membershipFee ?? undefined,
      },
      create: {
        id: 'default',
        ...body,
      },
    });
    return NextResponse.json(settings);
  } catch (error) {
    console.error('Settings PUT error:', error);
    return NextResponse.json({ error: 'Failed to update settings' }, { status: 500 });
  }
}

// PATCH /api/settings/password - Change admin password
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { username, currentPassword, newPassword } = body;

    if (!username || !currentPassword || !newPassword) {
      return NextResponse.json({ error: 'All fields are required' }, { status: 400 });
    }

    if (newPassword.length < 6) {
      return NextResponse.json({ error: 'New password must be at least 6 characters' }, { status: 400 });
    }

    const admin = await db.admin.findUnique({ where: { username } });

    if (!admin) {
      return NextResponse.json({ error: 'Admin not found' }, { status: 404 });
    }

    const currentHash = hashPassword(currentPassword);
    if (currentHash !== admin.password) {
      return NextResponse.json({ error: 'Current password is incorrect' }, { status: 401 });
    }

    const newHash = hashPassword(newPassword);
    await db.admin.update({
      where: { username },
      data: { password: newHash },
    });

    return NextResponse.json({ success: true, message: 'Password updated successfully' });
  } catch (error) {
    console.error('Password update error:', error);
    return NextResponse.json({ error: 'Failed to update password' }, { status: 500 });
  }
}
