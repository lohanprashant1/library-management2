import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/staff
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const department = searchParams.get('department') || '';
    const isActive = searchParams.get('isActive');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { designation: { contains: search } },
        { department: { contains: search } },
        { email: { contains: search } },
      ];
    }
    if (department) where.department = department;
    if (isActive !== null && isActive !== undefined && isActive !== '') {
      where.isActive = isActive === 'true';
    }

    const [items, total] = await Promise.all([
      db.staff.findMany({
        where,
        orderBy: { sortOrder: 'asc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.staff.count({ where }),
    ]);

    return NextResponse.json({ items, total, page, limit });
  } catch (error) {
    console.error('Staff GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch staff' }, { status: 500 });
  }
}

// POST /api/staff
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const staff = await db.staff.create({
      data: {
        name: body.name,
        designation: body.designation || '',
        department: body.department || '',
        email: body.email || '',
        phone: body.phone || '',
        photo: body.photo || '',
        sortOrder: body.sortOrder || 0,
        isActive: body.isActive ?? true,
      },
    });
    return NextResponse.json(staff, { status: 201 });
  } catch (error) {
    console.error('Staff POST error:', error);
    return NextResponse.json({ error: 'Failed to create staff' }, { status: 500 });
  }
}

// PUT /api/staff
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'Staff ID is required' }, { status: 400 });
    }

    const existing = await db.staff.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Staff not found' }, { status: 404 });
    }

    const staff = await db.staff.update({
      where: { id },
      data: {
        name: data.name ?? undefined,
        designation: data.designation ?? undefined,
        department: data.department ?? undefined,
        email: data.email ?? undefined,
        phone: data.phone ?? undefined,
        photo: data.photo ?? undefined,
        sortOrder: data.sortOrder ?? undefined,
        isActive: data.isActive ?? undefined,
      },
    });
    return NextResponse.json(staff);
  } catch (error) {
    console.error('Staff PUT error:', error);
    return NextResponse.json({ error: 'Failed to update staff' }, { status: 500 });
  }
}

// DELETE /api/staff?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'Staff ID is required' }, { status: 400 });
    }

    await db.staff.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Staff DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete staff' }, { status: 500 });
  }
}
