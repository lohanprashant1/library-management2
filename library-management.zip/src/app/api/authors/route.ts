import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/authors
export async function GET() {
  try {
    const authors = await db.author.findMany({
      include: { _count: { select: { books: true } } },
      orderBy: { name: 'asc' },
    });
    return NextResponse.json(authors);
  } catch (error) {
    console.error('Authors GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch authors' }, { status: 500 });
  }
}

// POST /api/authors
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const author = await db.author.create({
      data: {
        name: body.name,
        bio: body.bio || '',
      },
    });
    return NextResponse.json(author, { status: 201 });
  } catch (error) {
    console.error('Authors POST error:', error);
    return NextResponse.json({ error: 'Failed to create author' }, { status: 500 });
  }
}

// PUT /api/authors
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;
    if (!id) {
      return NextResponse.json({ error: 'Author ID is required' }, { status: 400 });
    }
    const author = await db.author.update({
      where: { id },
      data: { name: data.name, bio: data.bio },
    });
    return NextResponse.json(author);
  } catch (error) {
    console.error('Authors PUT error:', error);
    return NextResponse.json({ error: 'Failed to update author' }, { status: 500 });
  }
}

// DELETE /api/authors?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'Author ID is required' }, { status: 400 });
    }
    const booksWithAuthor = await db.book.count({ where: { authorId: id } });
    if (booksWithAuthor > 0) {
      return NextResponse.json(
        { error: 'Cannot delete author with books. Reassign books first.' },
        { status: 400 }
      );
    }
    await db.author.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Authors DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete author' }, { status: 500 });
  }
}
