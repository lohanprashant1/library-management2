import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/new-arrivals
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const category = searchParams.get('category') || '';
    const itemType = searchParams.get('itemType') || '';
    const featured = searchParams.get('featured');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { author: { contains: search } },
        { description: { contains: search } },
      ];
    }
    if (category) where.category = category;
    if (itemType) where.itemType = itemType;
    if (featured !== null && featured !== undefined && featured !== '') {
      where.featured = featured === 'true';
    }

    const [items, total] = await Promise.all([
      db.newArrival.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.newArrival.count({ where }),
    ]);

    return NextResponse.json({ items, total, page, limit });
  } catch (error) {
    console.error('New Arrivals GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch new arrivals' }, { status: 500 });
  }
}

// POST /api/new-arrivals
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const newArrival = await db.newArrival.create({
      data: {
        title: body.title,
        author: body.author,
        category: body.category,
        itemType: body.itemType || 'Book',
        description: body.description,
        coverImage: body.coverImage,
        arrivalDate: body.arrivalDate ? new Date(body.arrivalDate) : undefined,
        featured: body.featured ?? false,
      },
    });
    return NextResponse.json(newArrival, { status: 201 });
  } catch (error) {
    console.error('New Arrivals POST error:', error);
    return NextResponse.json({ error: 'Failed to create new arrival' }, { status: 500 });
  }
}

// PUT /api/new-arrivals
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'New Arrival ID is required' }, { status: 400 });
    }

    const existing = await db.newArrival.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'New Arrival not found' }, { status: 404 });
    }

    const newArrival = await db.newArrival.update({
      where: { id },
      data: {
        title: data.title ?? undefined,
        author: data.author ?? undefined,
        category: data.category ?? undefined,
        itemType: data.itemType ?? undefined,
        description: data.description ?? undefined,
        coverImage: data.coverImage ?? undefined,
        arrivalDate: data.arrivalDate ? new Date(data.arrivalDate) : undefined,
        featured: data.featured ?? undefined,
      },
    });
    return NextResponse.json(newArrival);
  } catch (error) {
    console.error('New Arrivals PUT error:', error);
    return NextResponse.json({ error: 'Failed to update new arrival' }, { status: 500 });
  }
}

// DELETE /api/new-arrivals?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'New Arrival ID is required' }, { status: 400 });
    }

    await db.newArrival.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('New Arrivals DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete new arrival' }, { status: 500 });
  }
}
