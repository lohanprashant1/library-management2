import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';
import * as XLSX from 'xlsx';

// ─── GET: Download templates and export data ──────────────────────────────

export async function GET(request: NextRequest) {
  try {
    const type = request.nextUrl.searchParams.get('type');

    // ── BOOKS ──
    if (type === 'books-template') {
      const wb = XLSX.utils.book_new();
      const categories = await db.category.findMany({ select: { name: true } });
      const authors = await db.author.findMany({ select: { name: true } });
      const headers = ['Title*', 'ISBN', 'Author*', 'Category*', 'Publisher', 'Publish Year', 'Total Copies*', 'Shelf Location', 'Description'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(9).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 15 }, { wch: 25 }, { wch: 20 }, { wch: 20 }, { wch: 12 }, { wch: 12 }, { wch: 15 }, { wch: 40 }];
      XLSX.utils.book_append_sheet(wb, ws, 'Books Template');
      const catData = [['Available Categories:'], ...categories.map(c => [c.name])];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(catData), 'Categories');
      const authData = [['Available Authors:'], ...authors.map(a => [a.name])];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(authData), 'Authors');
      return xlsxResponse(wb, 'books_template.xlsx');
    }

    if (type === 'books-data') {
      const books = await db.book.findMany({ include: { category: true, author: true }, orderBy: { title: 'asc' } });
      const data = [['Title', 'ISBN', 'Author', 'Category', 'Publisher', 'Publish Year', 'Total Copies', 'Available', 'Shelf Location', 'Description'],
        ...books.map(b => [b.title, b.isbn, b.author.name, b.category.name, b.publisher, b.publishYear, b.totalCopies, b.availableCopies, b.shelfLocation, b.description])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 15 }, { wch: 25 }, { wch: 20 }, { wch: 20 }, { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 15 }, { wch: 40 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All Books');
      return xlsxResponse(wb, 'library_books.xlsx');
    }

    // ── MEMBERS ──
    if (type === 'members-template') {
      const wb = XLSX.utils.book_new();
      const headers = ['Name*', 'Email*', 'Phone*', 'Address', 'Date of Birth', 'Gender*', 'Occupation'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(7).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 25 }, { wch: 30 }, { wch: 15 }, { wch: 40 }, { wch: 20 }, { wch: 10 }, { wch: 20 }];
      XLSX.utils.book_append_sheet(wb, ws, 'Members Template');
      const genderRef = [['Gender Options:'], ['Male'], ['Female'], ['Other']];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(genderRef), 'Gender Options');
      return xlsxResponse(wb, 'members_template.xlsx');
    }

    if (type === 'members-data') {
      const members = await db.member.findMany({ orderBy: { name: 'asc' } });
      const data = [['Member ID', 'Name', 'Email', 'Phone', 'Address', 'Date of Birth', 'Gender', 'Occupation', 'Status', 'Membership Date', 'Expiry Date'],
        ...members.map(m => [m.memberId, m.name, m.email, m.phone, m.address, m.dateOfBirth, m.gender, m.occupation, m.status, fmtDate(m.membershipDate), fmtDate(m.expiryDate)])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 12 }, { wch: 25 }, { wch: 30 }, { wch: 15 }, { wch: 40 }, { wch: 15 }, { wch: 10 }, { wch: 20 }, { wch: 10 }, { wch: 15 }, { wch: 15 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All Members');
      return xlsxResponse(wb, 'library_members.xlsx');
    }

    // ── EVENTS ──
    if (type === 'events-template') {
      const wb = XLSX.utils.book_new();
      const headers = ['Title*', 'Description', 'Event Date*', 'Event Time', 'Venue', 'Type*', 'Status*'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(7).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 50 }, { wch: 15 }, { wch: 12 }, { wch: 25 }, { wch: 15 }, { wch: 12 }];
      XLSX.utils.book_append_sheet(wb, ws, 'Events Template');
      const typeRef = [['Type Options:'], ['Event'], ['Announcement'], ['Workshop']];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(typeRef), 'Type Options');
      const statusRef = [['Status Options:'], ['Upcoming'], ['Ongoing'], ['Completed'], ['Cancelled']];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(statusRef), 'Status Options');
      return xlsxResponse(wb, 'events_template.xlsx');
    }

    if (type === 'events-data') {
      const items = await db.event.findMany({ orderBy: { eventDate: 'desc' } });
      const data = [['Title', 'Description', 'Event Date', 'Event Time', 'Venue', 'Type', 'Status'],
        ...items.map(e => [e.title, e.description, e.eventDate, e.eventTime, e.venue, e.type, e.status])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 50 }, { wch: 15 }, { wch: 12 }, { wch: 25 }, { wch: 15 }, { wch: 12 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All Events');
      return xlsxResponse(wb, 'library_events.xlsx');
    }

    // ── E-BOOKS ──
    if (type === 'ebooks-template') {
      const wb = XLSX.utils.book_new();
      const headers = ['Title*', 'Author', 'Description', 'Category', 'ISBN', 'Publisher', 'File URL', 'File Size', 'Format*', 'Access Level*'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(10).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 25 }, { wch: 50 }, { wch: 20 }, { wch: 15 }, { wch: 20 }, { wch: 40 }, { wch: 12 }, { wch: 10 }, { wch: 15 }];
      XLSX.utils.book_append_sheet(wb, ws, 'EBooks Template');
      const fmtRef = [['Format Options:'], ['PDF'], ['EPUB'], ['DOC'], ['MOBI']];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(fmtRef), 'Format Options');
      const accessRef = [['Access Options:'], ['All'], ['Members'], ['Staff']];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(accessRef), 'Access Options');
      return xlsxResponse(wb, 'ebooks_template.xlsx');
    }

    if (type === 'ebooks-data') {
      const items = await db.eBook.findMany({ orderBy: { addedAt: 'desc' } });
      const data = [['Title', 'Author', 'Description', 'Category', 'ISBN', 'Publisher', 'File Size', 'Format', 'Access Level'],
        ...items.map(e => [e.title, e.author, e.description, e.category, e.isbn, e.publisher, e.fileSize, e.format, e.accessLevel])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 25 }, { wch: 50 }, { wch: 20 }, { wch: 15 }, { wch: 20 }, { wch: 12 }, { wch: 10 }, { wch: 15 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All EBooks');
      return xlsxResponse(wb, 'library_ebooks.xlsx');
    }

    // ── FAQS ──
    if (type === 'faqs-template') {
      const wb = XLSX.utils.book_new();
      const headers = ['Question*', 'Answer*', 'Category', 'Sort Order', 'Active (true/false)'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(5).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 50 }, { wch: 60 }, { wch: 20 }, { wch: 12 }, { wch: 18 }];
      XLSX.utils.book_append_sheet(wb, ws, 'FAQs Template');
      const catRef = [['Category Options:'], ['General'], ['Membership'], ['Borrowing'], ['Events'], ['Digital'], ['Services']];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(catRef), 'Category Options');
      return xlsxResponse(wb, 'faqs_template.xlsx');
    }

    if (type === 'faqs-data') {
      const items = await db.fAQ.findMany({ orderBy: { sortOrder: 'asc' } });
      const data = [['Question', 'Answer', 'Category', 'Sort Order', 'Active'],
        ...items.map(f => [f.question, f.answer, f.category, f.sortOrder, f.isActive ? 'Yes' : 'No'])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 50 }, { wch: 60 }, { wch: 20 }, { wch: 12 }, { wch: 10 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All FAQs');
      return xlsxResponse(wb, 'library_faqs.xlsx');
    }

    // ── STAFF ──
    if (type === 'staff-template') {
      const wb = XLSX.utils.book_new();
      const headers = ['Name*', 'Designation', 'Department', 'Email', 'Phone', 'Photo URL', 'Sort Order', 'Active (true/false)'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(8).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 25 }, { wch: 25 }, { wch: 20 }, { wch: 30 }, { wch: 15 }, { wch: 40 }, { wch: 12 }, { wch: 18 }];
      XLSX.utils.book_append_sheet(wb, ws, 'Staff Template');
      return xlsxResponse(wb, 'staff_template.xlsx');
    }

    if (type === 'staff-data') {
      const items = await db.staff.findMany({ orderBy: { sortOrder: 'asc' } });
      const data = [['Name', 'Designation', 'Department', 'Email', 'Phone', 'Sort Order', 'Active'],
        ...items.map(s => [s.name, s.designation, s.department, s.email, s.phone, s.sortOrder, s.isActive ? 'Yes' : 'No'])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 25 }, { wch: 25 }, { wch: 20 }, { wch: 30 }, { wch: 15 }, { wch: 12 }, { wch: 10 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All Staff');
      return xlsxResponse(wb, 'library_staff.xlsx');
    }

    // ── DONORS ──
    if (type === 'donors-template') {
      const wb = XLSX.utils.book_new();
      const headers = ['Name*', 'Designation', 'Organization', 'Amount', 'Year', 'Description', 'Donor Type (Individual/Corporate/Alumni)', 'Featured (true/false)'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(8).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 25 }, { wch: 25 }, { wch: 30 }, { wch: 15 }, { wch: 10 }, { wch: 40 }, { wch: 35 }, { wch: 18 }];
      XLSX.utils.book_append_sheet(wb, ws, 'Donors Template');
      const typeRef = [['Donor Type Options:'], ['Individual'], ['Corporate'], ['Alumni']];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(typeRef), 'Donor Type');
      return xlsxResponse(wb, 'donors_template.xlsx');
    }

    if (type === 'donors-data') {
      const items = await db.donor.findMany({ orderBy: { year: 'desc' } });
      const data = [['Name', 'Designation', 'Organization', 'Amount', 'Year', 'Description', 'Donor Type', 'Featured'],
        ...items.map(d => [d.name, d.designation, d.organization, d.amount, d.year, d.description, d.donorType, d.isFeatured ? 'Yes' : 'No'])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 25 }, { wch: 25 }, { wch: 30 }, { wch: 15 }, { wch: 10 }, { wch: 40 }, { wch: 15 }, { wch: 10 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All Donors');
      return xlsxResponse(wb, 'library_donors.xlsx');
    }

    // ── NEW ARRIVALS ──
    if (type === 'new-arrivals-template') {
      const wb = XLSX.utils.book_new();
      const headers = ['Title*', 'Author', 'Category', 'Item Type (Book/Journal/Thesis/Report/AV)', 'Description', 'Arrival Date', 'Featured (true/false)'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(7).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 25 }, { wch: 20 }, { wch: 35 }, { wch: 40 }, { wch: 15 }, { wch: 18 }];
      XLSX.utils.book_append_sheet(wb, ws, 'New Arrivals Template');
      const typeRef = [['Item Type Options:'], ['Book'], ['Journal'], ['Thesis'], ['Report'], ['AV']];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(typeRef), 'Item Types');
      return xlsxResponse(wb, 'new_arrivals_template.xlsx');
    }

    if (type === 'new-arrivals-data') {
      const items = await db.newArrival.findMany({ orderBy: { arrivalDate: 'desc' } });
      const data = [['Title', 'Author', 'Category', 'Item Type', 'Description', 'Arrival Date', 'Featured'],
        ...items.map(n => [n.title, n.author, n.category, n.itemType, n.description, n.arrivalDate, n.featured ? 'Yes' : 'No'])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 25 }, { wch: 20 }, { wch: 15 }, { wch: 40 }, { wch: 15 }, { wch: 10 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All New Arrivals');
      return xlsxResponse(wb, 'library_new_arrivals.xlsx');
    }

    // ── E-RESOURCES ──
    if (type === 'eresources-template') {
      const wb = XLSX.utils.book_new();
      const headers = ['Name*', 'URL', 'Description', 'Category (Database/e-Journal/e-Book/Thesis/Standard)', 'Access Type (IP Based/Remote/Open Access)', 'Publisher', 'Sort Order', 'Active (true/false)'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(8).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 25 }, { wch: 40 }, { wch: 40 }, { wch: 40 }, { wch: 35 }, { wch: 25 }, { wch: 12 }, { wch: 18 }];
      XLSX.utils.book_append_sheet(wb, ws, 'EResources Template');
      const catRef = [['Category Options:'], ['Database'], ['e-Journal'], ['e-Book'], ['Thesis'], ['Standard']];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(catRef), 'Categories');
      const accessRef = [['Access Type Options:'], ['IP Based'], ['Remote'], ['Open Access']];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(accessRef), 'Access Types');
      return xlsxResponse(wb, 'eresources_template.xlsx');
    }

    if (type === 'eresources-data') {
      const items = await db.eResource.findMany({ orderBy: { sortOrder: 'asc' } });
      const data = [['Name', 'URL', 'Description', 'Category', 'Access Type', 'Publisher', 'Sort Order', 'Active'],
        ...items.map(e => [e.name, e.url, e.description, e.category, e.accessType, e.publisher, e.sortOrder, e.isActive ? 'Yes' : 'No'])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 25 }, { wch: 40 }, { wch: 40 }, { wch: 15 }, { wch: 15 }, { wch: 25 }, { wch: 12 }, { wch: 10 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All EResources');
      return xlsxResponse(wb, 'library_eresources.xlsx');
    }

    // ── NOTICES ──
    if (type === 'notices-template') {
      const wb = XLSX.utils.book_new();
      const headers = ['Title*', 'Content', 'Type (General/Academic/Examination/Event/Holiday/Urgent)', 'Priority (Normal/High/Critical)', 'Publish Date', 'Expiry Date', 'Active (true/false)'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(7).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 50 }, { wch: 45 }, { wch: 30 }, { wch: 15 }, { wch: 15 }, { wch: 18 }];
      XLSX.utils.book_append_sheet(wb, ws, 'Notices Template');
      const typeRef = [['Type Options:'], ['General'], ['Academic'], ['Examination'], ['Event'], ['Holiday'], ['Urgent']];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(typeRef), 'Notice Types');
      const prioRef = [['Priority Options:'], ['Normal'], ['High'], ['Critical']];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(prioRef), 'Priority');
      return xlsxResponse(wb, 'notices_template.xlsx');
    }

    if (type === 'notices-data') {
      const items = await db.notice.findMany({ orderBy: { publishDate: 'desc' } });
      const data = [['Title', 'Content', 'Type', 'Priority', 'Publish Date', 'Expiry Date', 'Active'],
        ...items.map(n => [n.title, n.content, n.type, n.priority, n.publishDate, n.expiryDate, n.isActive ? 'Yes' : 'No'])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 50 }, { wch: 15 }, { wch: 12 }, { wch: 15 }, { wch: 15 }, { wch: 10 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All Notices');
      return xlsxResponse(wb, 'library_notices.xlsx');
    }

    // ── ASK LIBRARIAN ──
    if (type === 'ask-librarian-template') {
      const wb = XLSX.utils.book_new();
      const headers = ['Question*', 'Answer', 'Name', 'Email', 'Category', 'Status (Pending/Answered/Closed)'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(6).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 50 }, { wch: 60 }, { wch: 25 }, { wch: 30 }, { wch: 20 }, { wch: 30 }];
      XLSX.utils.book_append_sheet(wb, ws, 'Ask Librarian Template');
      const statusRef = [['Status Options:'], ['Pending'], ['Answered'], ['Closed']];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(statusRef), 'Status');
      return xlsxResponse(wb, 'ask_librarian_template.xlsx');
    }

    if (type === 'ask-librarian-data') {
      const items = await db.askLibrarian.findMany({ orderBy: { createdAt: 'desc' } });
      const data = [['Question', 'Answer', 'Name', 'Email', 'Category', 'Status', 'Created At'],
        ...items.map(a => [a.question, a.answer, a.name, a.email, a.category, a.status, fmtDate(a.createdAt)])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 50 }, { wch: 60 }, { wch: 25 }, { wch: 30 }, { wch: 20 }, { wch: 12 }, { wch: 15 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All Ask Librarian');
      return xlsxResponse(wb, 'library_ask_librarian.xlsx');
    }

    // ── FACULTY PUBLICATIONS ──
    if (type === 'faculty-publications-template') {
      const wb = XLSX.utils.book_new();
      const headers = ['Title*', 'Author', 'Department', 'Journal', 'Year', 'DOI', 'Abstract', 'Pub Type (Journal/Conference/Book/Thesis/Report/Patent)', 'URL'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(9).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 40 }, { wch: 25 }, { wch: 20 }, { wch: 30 }, { wch: 10 }, { wch: 30 }, { wch: 60 }, { wch: 40 }, { wch: 40 }];
      XLSX.utils.book_append_sheet(wb, ws, 'Faculty Publications Template');
      const typeRef = [['Pub Type Options:'], ['Journal'], ['Conference'], ['Book'], ['Thesis'], ['Report'], ['Patent']];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(typeRef), 'Pub Types');
      return xlsxResponse(wb, 'faculty_publications_template.xlsx');
    }

    if (type === 'faculty-publications-data') {
      const items = await db.facultyPublication.findMany({ orderBy: { year: 'desc' } });
      const data = [['Title', 'Author', 'Department', 'Journal', 'Year', 'DOI', 'Abstract', 'Pub Type', 'URL'],
        ...items.map(f => [f.title, f.author, f.department, f.journal, f.year, f.doi, f.abstract, f.pubType, f.url])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 40 }, { wch: 25 }, { wch: 20 }, { wch: 30 }, { wch: 10 }, { wch: 30 }, { wch: 60 }, { wch: 15 }, { wch: 40 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All Faculty Publications');
      return xlsxResponse(wb, 'library_faculty_publications.xlsx');
    }

    // ── PAST PAPERS ──
    if (type === 'past-papers-template') {
      const wb = XLSX.utils.book_new();
      const headers = ['Title*', 'Course', 'Course Code', 'Department', 'Year', 'Semester', 'File URL'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(7).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 25 }, { wch: 15 }, { wch: 20 }, { wch: 10 }, { wch: 12 }, { wch: 40 }];
      XLSX.utils.book_append_sheet(wb, ws, 'Past Papers Template');
      return xlsxResponse(wb, 'past_papers_template.xlsx');
    }

    if (type === 'past-papers-data') {
      const items = await db.pastPaper.findMany({ orderBy: { year: 'desc' } });
      const data = [['Title', 'Course', 'Course Code', 'Department', 'Year', 'Semester', 'File URL'],
        ...items.map(p => [p.title, p.course, p.courseCode, p.department, p.year, p.semester, p.fileUrl])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 25 }, { wch: 15 }, { wch: 20 }, { wch: 10 }, { wch: 12 }, { wch: 40 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All Past Papers');
      return xlsxResponse(wb, 'library_past_papers.xlsx');
    }

    // ── LIBRARY RULES ──
    if (type === 'library-rules-template') {
      const wb = XLSX.utils.book_new();
      const headers = ['Title*', 'Content', 'Category (General/Circulation/Membership/Digital/Conduct)', 'Sort Order', 'Active (true/false)'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(5).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 60 }, { wch: 40 }, { wch: 12 }, { wch: 18 }];
      XLSX.utils.book_append_sheet(wb, ws, 'Library Rules Template');
      const catRef = [['Category Options:'], ['General'], ['Circulation'], ['Membership'], ['Digital'], ['Conduct']];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(catRef), 'Categories');
      return xlsxResponse(wb, 'library_rules_template.xlsx');
    }

    if (type === 'library-rules-data') {
      const items = await db.libraryRule.findMany({ orderBy: { sortOrder: 'asc' } });
      const data = [['Title', 'Content', 'Category', 'Sort Order', 'Active'],
        ...items.map(r => [r.title, r.content, r.category, r.sortOrder, r.isActive ? 'Yes' : 'No'])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 60 }, { wch: 20 }, { wch: 12 }, { wch: 10 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All Library Rules');
      return xlsxResponse(wb, 'library_rules.xlsx');
    }

    // ── PHOTO GALLERY ──
    if (type === 'photo-gallery-template') {
      const wb = XLSX.utils.book_new();
      const headers = ['Title*', 'Description', 'Image URL', 'Event', 'Date', 'Sort Order', 'Active (true/false)'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(7).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 40 }, { wch: 40 }, { wch: 25 }, { wch: 15 }, { wch: 12 }, { wch: 18 }];
      XLSX.utils.book_append_sheet(wb, ws, 'Photo Gallery Template');
      return xlsxResponse(wb, 'photo_gallery_template.xlsx');
    }

    if (type === 'photo-gallery-data') {
      const items = await db.photoGallery.findMany({ orderBy: { sortOrder: 'asc' } });
      const data = [['Title', 'Description', 'Image URL', 'Event', 'Date', 'Sort Order', 'Active'],
        ...items.map(p => [p.title, p.description, p.image, p.event, p.date, p.sortOrder, p.isActive ? 'Yes' : 'No'])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 40 }, { wch: 40 }, { wch: 25 }, { wch: 15 }, { wch: 12 }, { wch: 10 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All Photo Gallery');
      return xlsxResponse(wb, 'library_photo_gallery.xlsx');
    }

    // ── NEWSLETTERS ──
    if (type === 'newsletters-template') {
      const wb = XLSX.utils.book_new();
      const headers = ['Title*', 'Description', 'File URL', 'Issue', 'Date'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(5).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 40 }, { wch: 40 }, { wch: 15 }, { wch: 15 }];
      XLSX.utils.book_append_sheet(wb, ws, 'Newsletters Template');
      return xlsxResponse(wb, 'newsletters_template.xlsx');
    }

    if (type === 'newsletters-data') {
      const items = await db.newsletter.findMany({ orderBy: { date: 'desc' } });
      const data = [['Title', 'Description', 'File URL', 'Issue', 'Date'],
        ...items.map(n => [n.title, n.description, n.fileUrl, n.issue, n.date])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 40 }, { wch: 40 }, { wch: 15 }, { wch: 15 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All Newsletters');
      return xlsxResponse(wb, 'library_newsletters.xlsx');
    }

    // ── COMMITTEE ──
    if (type === 'committee-template') {
      const wb = XLSX.utils.book_new();
      const headers = ['Name*', 'Designation', 'Department', 'Role (Chairperson/Vice-Chair/Secretary/Member)', 'Email', 'Phone', 'Photo URL', 'Sort Order', 'Active (true/false)'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(9).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 25 }, { wch: 25 }, { wch: 20 }, { wch: 40 }, { wch: 30 }, { wch: 15 }, { wch: 40 }, { wch: 12 }, { wch: 18 }];
      XLSX.utils.book_append_sheet(wb, ws, 'Committee Template');
      const roleRef = [['Role Options:'], ['Chairperson'], ['Vice-Chair'], ['Secretary'], ['Member']];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(roleRef), 'Roles');
      return xlsxResponse(wb, 'committee_template.xlsx');
    }

    if (type === 'committee-data') {
      const items = await db.committee.findMany({ orderBy: { sortOrder: 'asc' } });
      const data = [['Name', 'Designation', 'Department', 'Role', 'Email', 'Phone', 'Sort Order', 'Active'],
        ...items.map(c => [c.name, c.designation, c.department, c.role, c.email, c.phone, c.sortOrder, c.isActive ? 'Yes' : 'No'])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 25 }, { wch: 25 }, { wch: 20 }, { wch: 15 }, { wch: 30 }, { wch: 15 }, { wch: 12 }, { wch: 10 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All Committee');
      return xlsxResponse(wb, 'library_committee.xlsx');
    }

    // ── RESEARCH GUIDES ──
    if (type === 'research-guides-template') {
      const wb = XLSX.utils.book_new();
      const headers = ['Title*', 'Description', 'Category', 'Content', 'Author', 'File URL', 'Sort Order', 'Active (true/false)'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(8).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 40 }, { wch: 20 }, { wch: 60 }, { wch: 25 }, { wch: 40 }, { wch: 12 }, { wch: 18 }];
      XLSX.utils.book_append_sheet(wb, ws, 'Research Guides Template');
      return xlsxResponse(wb, 'research_guides_template.xlsx');
    }

    if (type === 'research-guides-data') {
      const items = await db.researchGuide.findMany({ orderBy: { sortOrder: 'asc' } });
      const data = [['Title', 'Description', 'Category', 'Author', 'File URL', 'Sort Order', 'Active'],
        ...items.map(r => [r.title, r.description, r.category, r.author, r.fileUrl, r.sortOrder, r.isActive ? 'Yes' : 'No'])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 40 }, { wch: 20 }, { wch: 25 }, { wch: 40 }, { wch: 12 }, { wch: 10 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All Research Guides');
      return xlsxResponse(wb, 'library_research_guides.xlsx');
    }

    // ── CAS ALERTS ──
    if (type === 'cas-alerts-template') {
      const wb = XLSX.utils.book_new();
      const headers = ['Title*', 'Description', 'Category (New Arrivals/JTOC/New Issues/Conferences/Grants)', 'Alert Date', 'Source', 'URL', 'Active (true/false)'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(7).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 40 }, { wch: 45 }, { wch: 15 }, { wch: 25 }, { wch: 40 }, { wch: 18 }];
      XLSX.utils.book_append_sheet(wb, ws, 'CAS Alerts Template');
      const catRef = [['Category Options:'], ['New Arrivals'], ['JTOC'], ['New Issues'], ['Conferences'], ['Grants']];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(catRef), 'Categories');
      return xlsxResponse(wb, 'cas_alerts_template.xlsx');
    }

    if (type === 'cas-alerts-data') {
      const items = await db.cASAlert.findMany({ orderBy: { alertDate: 'desc' } });
      const data = [['Title', 'Description', 'Category', 'Alert Date', 'Source', 'URL', 'Active'],
        ...items.map(c => [c.title, c.description, c.category, c.alertDate, c.source, c.url, c.isActive ? 'Yes' : 'No'])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 40 }, { wch: 15 }, { wch: 15 }, { wch: 25 }, { wch: 40 }, { wch: 10 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All CAS Alerts');
      return xlsxResponse(wb, 'library_cas_alerts.xlsx');
    }

    // ── ILL REQUESTS ──
    if (type === 'ill-requests-template') {
      const wb = XLSX.utils.book_new();
      const headers = ['Title*', 'Author', 'Journal', 'Year', 'Requester Name*', 'Requester Email*', 'Department', 'Status (Pending/Processing/Fulfilled/Rejected)', 'Remarks'];
      const data = [headers];
      for (let i = 0; i < 5; i++) data.push(Array(9).fill(''));
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 25 }, { wch: 25 }, { wch: 10 }, { wch: 25 }, { wch: 30 }, { wch: 20 }, { wch: 40 }, { wch: 30 }];
      XLSX.utils.book_append_sheet(wb, ws, 'ILL Requests Template');
      const statusRef = [['Status Options:'], ['Pending'], ['Processing'], ['Fulfilled'], ['Rejected']];
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(statusRef), 'Status');
      return xlsxResponse(wb, 'ill_requests_template.xlsx');
    }

    if (type === 'ill-requests-data') {
      const items = await db.iLLRequest.findMany({ orderBy: { createdAt: 'desc' } });
      const data = [['Title', 'Author', 'Journal', 'Year', 'Requester Name', 'Requester Email', 'Department', 'Status', 'Remarks', 'Created At'],
        ...items.map(r => [r.title, r.author, r.journal, r.year, r.requesterName, r.requesterEmail, r.department, r.status, r.remarks, fmtDate(r.createdAt)])];
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      ws['!cols'] = [{ wch: 30 }, { wch: 25 }, { wch: 25 }, { wch: 10 }, { wch: 25 }, { wch: 30 }, { wch: 20 }, { wch: 15 }, { wch: 30 }, { wch: 15 }];
      XLSX.utils.book_append_sheet(wb, ws, 'All ILL Requests');
      return xlsxResponse(wb, 'library_ill_requests.xlsx');
    }

    return NextResponse.json({ error: 'Invalid type. Use books-template, books-data, members-template, members-data, events-template, events-data, ebooks-template, ebooks-data, faqs-template, faqs-data, staff-template, staff-data, donors-template, donors-data, new-arrivals-template, new-arrivals-data, eresources-template, eresources-data, notices-template, notices-data, ask-librarian-template, ask-librarian-data, faculty-publications-template, faculty-publications-data, past-papers-template, past-papers-data, library-rules-template, library-rules-data, photo-gallery-template, photo-gallery-data, newsletters-template, newsletters-data, committee-template, committee-data, research-guides-template, research-guides-data, cas-alerts-template, cas-alerts-data, ill-requests-template, or ill-requests-data' }, { status: 400 });
  } catch (error) {
    console.error('Excel GET error:', error);
    return NextResponse.json({ error: 'Failed to generate Excel file' }, { status: 500 });
  }
}

// ─── POST: Upload Excel files ─────────────────────────────────────────────

export async function POST(request: NextRequest) {
  try {
    const type = request.nextUrl.searchParams.get('type');
    const formData = await request.formData();
    const file = formData.get('file') as File;

    if (!file) {
      return NextResponse.json({ error: 'No file uploaded' }, { status: 400 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());
    const wb = XLSX.read(buffer, { type: 'buffer' });

    if (type === 'books') {
      const ws = wb.Sheets['Books Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };

      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const title = row['Title*'] || row['Title'] || '';
        const authorName = row['Author*'] || row['Author'] || '';
        const categoryName = row['Category*'] || row['Category'] || '';
        if (!title || !authorName || !categoryName) { results.errors.push(`Row ${i + 2}: Missing required fields`); continue; }

        let author = await db.author.findUnique({ where: { name: authorName } });
        if (!author) author = await db.author.create({ data: { name: authorName } });

        let category = await db.category.findUnique({ where: { name: categoryName } });
        if (!category) category = await db.category.create({ data: { name: categoryName } });

        const totalCopies = parseInt(row['Total Copies*'] || row['Total Copies'] || '1') || 1;
        await db.book.create({
          data: { title, isbn: row['ISBN'] || '', description: row['Description'] || '', publisher: row['Publisher'] || '', publishYear: parseInt(row['Publish Year'] || String(new Date().getFullYear())) || new Date().getFullYear(), totalCopies, availableCopies: totalCopies, categoryId: category.id, authorId: author.id, shelfLocation: row['Shelf Location'] || '' },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} books successfully`, ...results });
    }

    if (type === 'members') {
      const ws = wb.Sheets['Members Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };
      const count = await db.member.count();

      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const name = row['Name*'] || row['Name'] || '';
        const email = row['Email*'] || row['Email'] || '';
        const phone = row['Phone*'] || row['Phone'] || '';
        if (!name || !email || !phone) { results.errors.push(`Row ${i + 2}: Missing required fields`); continue; }
        if (await db.member.findUnique({ where: { email } })) { results.errors.push(`Row ${i + 2}: Email "${email}" exists`); continue; }

        const memberId = `LIB-${String(count + i + 1).padStart(5, '0')}`;
        const expiryDate = new Date(); expiryDate.setFullYear(expiryDate.getFullYear() + 1);
        await db.member.create({
          data: { memberId, name, email, phone, address: row['Address'] || '', dateOfBirth: row['Date of Birth (DD/MM/YYYY)'] || row['Date of Birth'] || '', gender: row['Gender*'] || row['Gender'] || 'Other', occupation: row['Occupation'] || '', status: 'Active', expiryDate },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} members successfully`, ...results });
    }

    if (type === 'events') {
      const ws = wb.Sheets['Events Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const title = row['Title*'] || row['Title'] || '';
        const eventDate = row['Event Date*'] || row['Event Date'] || '';
        if (!title) { results.errors.push(`Row ${i + 2}: Missing title`); continue; }
        await db.event.create({
          data: { title, description: row['Description'] || '', eventDate, eventTime: row['Event Time'] || '', venue: row['Venue'] || '', type: row['Type*'] || row['Type'] || 'Event', status: row['Status*'] || row['Status'] || 'Upcoming' },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} events successfully`, ...results });
    }

    if (type === 'ebooks') {
      const ws = wb.Sheets['EBooks Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const title = row['Title*'] || row['Title'] || '';
        if (!title) { results.errors.push(`Row ${i + 2}: Missing title`); continue; }
        await db.eBook.create({
          data: { title, author: row['Author'] || '', description: row['Description'] || '', category: row['Category'] || '', isbn: row['ISBN'] || '', publisher: row['Publisher'] || '', fileUrl: row['File URL'] || '', fileSize: row['File Size'] || '', format: row['Format*'] || row['Format'] || 'PDF', accessLevel: row['Access Level*'] || row['Access Level'] || 'All' },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} e-books successfully`, ...results });
    }

    if (type === 'faqs') {
      const ws = wb.Sheets['FAQs Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const question = row['Question*'] || row['Question'] || '';
        const answer = row['Answer*'] || row['Answer'] || '';
        if (!question || !answer) { results.errors.push(`Row ${i + 2}: Missing question or answer`); continue; }
        const isActive = (row['Active (true/false)'] || 'true').toString().toLowerCase() === 'true';
        await db.fAQ.create({
          data: { question, answer, category: row['Category'] || 'General', sortOrder: parseInt(row['Sort Order'] || '0') || 0, isActive },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} FAQs successfully`, ...results });
    }

    if (type === 'staff') {
      const ws = wb.Sheets['Staff Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const name = row['Name*'] || row['Name'] || '';
        if (!name) { results.errors.push(`Row ${i + 2}: Missing name`); continue; }
        const isActive = (row['Active (true/false)'] || 'true').toString().toLowerCase() === 'true';
        await db.staff.create({
          data: { name, designation: row['Designation'] || '', department: row['Department'] || '', email: row['Email'] || '', phone: row['Phone'] || '', photo: row['Photo URL'] || '', sortOrder: parseInt(row['Sort Order'] || '0') || 0, isActive },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} staff members successfully`, ...results });
    }

    // ── DONORS ──
    if (type === 'donors') {
      const ws = wb.Sheets['Donors Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const name = row['Name*'] || row['Name'] || '';
        if (!name) { results.errors.push(`Row ${i + 2}: Missing name`); continue; }
        const isFeatured = (row['Featured (true/false)'] || 'false').toString().toLowerCase() === 'true';
        await db.donor.create({
          data: { name, designation: row['Designation'] || '', organization: row['Organization'] || '', amount: parseFloat(row['Amount'] || '0') || 0, year: row['Year'] || '', description: row['Description'] || '', donorType: row['Donor Type (Individual/Corporate/Alumni)'] || row['Donor Type'] || 'Individual', isFeatured },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} donors successfully`, ...results });
    }

    // ── NEW ARRIVALS ──
    if (type === 'new-arrivals') {
      const ws = wb.Sheets['New Arrivals Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const title = row['Title*'] || row['Title'] || '';
        if (!title) { results.errors.push(`Row ${i + 2}: Missing title`); continue; }
        const featured = (row['Featured (true/false)'] || 'false').toString().toLowerCase() === 'true';
        await db.newArrival.create({
          data: { title, author: row['Author'] || '', category: row['Category'] || '', itemType: row['Item Type (Book/Journal/Thesis/Report/AV)'] || row['Item Type'] || 'Book', description: row['Description'] || '', arrivalDate: row['Arrival Date'] || '', featured },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} new arrivals successfully`, ...results });
    }

    // ── E-RESOURCES ──
    if (type === 'eresources') {
      const ws = wb.Sheets['EResources Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const name = row['Name*'] || row['Name'] || '';
        if (!name) { results.errors.push(`Row ${i + 2}: Missing name`); continue; }
        const isActive = (row['Active (true/false)'] || 'true').toString().toLowerCase() === 'true';
        await db.eResource.create({
          data: { name, url: row['URL'] || '', description: row['Description'] || '', category: row['Category (Database/e-Journal/e-Book/Thesis/Standard)'] || row['Category'] || 'Database', accessType: row['Access Type (IP Based/Remote/Open Access)'] || row['Access Type'] || 'IP Based', publisher: row['Publisher'] || '', sortOrder: parseInt(row['Sort Order'] || '0') || 0, isActive },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} e-resources successfully`, ...results });
    }

    // ── NOTICES ──
    if (type === 'notices') {
      const ws = wb.Sheets['Notices Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const title = row['Title*'] || row['Title'] || '';
        if (!title) { results.errors.push(`Row ${i + 2}: Missing title`); continue; }
        const isActive = (row['Active (true/false)'] || 'true').toString().toLowerCase() === 'true';
        await db.notice.create({
          data: { title, content: row['Content'] || '', type: row['Type (General/Academic/Examination/Event/Holiday/Urgent)'] || row['Type'] || 'General', priority: row['Priority (Normal/High/Critical)'] || row['Priority'] || 'Normal', publishDate: row['Publish Date'] || '', expiryDate: row['Expiry Date'] || '', isActive },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} notices successfully`, ...results });
    }

    // ── ASK LIBRARIAN ──
    if (type === 'ask-librarian') {
      const ws = wb.Sheets['Ask Librarian Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const question = row['Question*'] || row['Question'] || '';
        if (!question) { results.errors.push(`Row ${i + 2}: Missing question`); continue; }
        await db.askLibrarian.create({
          data: { question, answer: row['Answer'] || '', name: row['Name'] || '', email: row['Email'] || '', category: row['Category'] || 'General', status: row['Status (Pending/Answered/Closed)'] || row['Status'] || 'Pending' },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} ask-librarian entries successfully`, ...results });
    }

    // ── FACULTY PUBLICATIONS ──
    if (type === 'faculty-publications') {
      const ws = wb.Sheets['Faculty Publications Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const title = row['Title*'] || row['Title'] || '';
        if (!title) { results.errors.push(`Row ${i + 2}: Missing title`); continue; }
        await db.facultyPublication.create({
          data: { title, author: row['Author'] || '', department: row['Department'] || '', journal: row['Journal'] || '', year: row['Year'] || '', doi: row['DOI'] || '', abstract: row['Abstract'] || '', pubType: row['Pub Type (Journal/Conference/Book/Thesis/Report/Patent)'] || row['Pub Type'] || 'Journal', url: row['URL'] || '' },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} faculty publications successfully`, ...results });
    }

    // ── PAST PAPERS ──
    if (type === 'past-papers') {
      const ws = wb.Sheets['Past Papers Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const title = row['Title*'] || row['Title'] || '';
        if (!title) { results.errors.push(`Row ${i + 2}: Missing title`); continue; }
        await db.pastPaper.create({
          data: { title, course: row['Course'] || '', courseCode: row['Course Code'] || '', department: row['Department'] || '', year: row['Year'] || '', semester: row['Semester'] || '', fileUrl: row['File URL'] || '' },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} past papers successfully`, ...results });
    }

    // ── LIBRARY RULES ──
    if (type === 'library-rules') {
      const ws = wb.Sheets['Library Rules Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const title = row['Title*'] || row['Title'] || '';
        if (!title) { results.errors.push(`Row ${i + 2}: Missing title`); continue; }
        const isActive = (row['Active (true/false)'] || 'true').toString().toLowerCase() === 'true';
        await db.libraryRule.create({
          data: { title, content: row['Content'] || '', category: row['Category (General/Circulation/Membership/Digital/Conduct)'] || row['Category'] || 'General', sortOrder: parseInt(row['Sort Order'] || '0') || 0, isActive },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} library rules successfully`, ...results });
    }

    // ── PHOTO GALLERY ──
    if (type === 'photo-gallery') {
      const ws = wb.Sheets['Photo Gallery Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const title = row['Title*'] || row['Title'] || '';
        if (!title) { results.errors.push(`Row ${i + 2}: Missing title`); continue; }
        const isActive = (row['Active (true/false)'] || 'true').toString().toLowerCase() === 'true';
        await db.photoGallery.create({
          data: { title, description: row['Description'] || '', image: row['Image URL'] || '', event: row['Event'] || '', date: row['Date'] || '', sortOrder: parseInt(row['Sort Order'] || '0') || 0, isActive },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} photo gallery entries successfully`, ...results });
    }

    // ── NEWSLETTERS ──
    if (type === 'newsletters') {
      const ws = wb.Sheets['Newsletters Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const title = row['Title*'] || row['Title'] || '';
        if (!title) { results.errors.push(`Row ${i + 2}: Missing title`); continue; }
        await db.newsletter.create({
          data: { title, description: row['Description'] || '', fileUrl: row['File URL'] || '', issue: row['Issue'] || '', date: row['Date'] || '' },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} newsletters successfully`, ...results });
    }

    // ── COMMITTEE ──
    if (type === 'committee') {
      const ws = wb.Sheets['Committee Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const name = row['Name*'] || row['Name'] || '';
        if (!name) { results.errors.push(`Row ${i + 2}: Missing name`); continue; }
        const isActive = (row['Active (true/false)'] || 'true').toString().toLowerCase() === 'true';
        await db.committee.create({
          data: { name, designation: row['Designation'] || '', department: row['Department'] || '', role: row['Role (Chairperson/Vice-Chair/Secretary/Member)'] || row['Role'] || 'Member', email: row['Email'] || '', phone: row['Phone'] || '', photo: row['Photo URL'] || '', sortOrder: parseInt(row['Sort Order'] || '0') || 0, isActive },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} committee members successfully`, ...results });
    }

    // ── RESEARCH GUIDES ──
    if (type === 'research-guides') {
      const ws = wb.Sheets['Research Guides Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const title = row['Title*'] || row['Title'] || '';
        if (!title) { results.errors.push(`Row ${i + 2}: Missing title`); continue; }
        const isActive = (row['Active (true/false)'] || 'true').toString().toLowerCase() === 'true';
        await db.researchGuide.create({
          data: { title, description: row['Description'] || '', category: row['Category'] || 'General', content: row['Content'] || '', author: row['Author'] || '', fileUrl: row['File URL'] || '', sortOrder: parseInt(row['Sort Order'] || '0') || 0, isActive },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} research guides successfully`, ...results });
    }

    // ── CAS ALERTS ──
    if (type === 'cas-alerts') {
      const ws = wb.Sheets['CAS Alerts Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const title = row['Title*'] || row['Title'] || '';
        if (!title) { results.errors.push(`Row ${i + 2}: Missing title`); continue; }
        const isActive = (row['Active (true/false)'] || 'true').toString().toLowerCase() === 'true';
        await db.cASAlert.create({
          data: { title, description: row['Description'] || '', category: row['Category (New Arrivals/JTOC/New Issues/Conferences/Grants)'] || row['Category'] || 'New Arrivals', alertDate: row['Alert Date'] || '', source: row['Source'] || '', url: row['URL'] || '', isActive },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} CAS alerts successfully`, ...results });
    }

    // ── ILL REQUESTS ──
    if (type === 'ill-requests') {
      const ws = wb.Sheets['ILL Requests Template'] || wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws) as Record<string, string>[];
      const results = { success: 0, errors: [] as string[] };
      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const title = row['Title*'] || row['Title'] || '';
        const requesterName = row['Requester Name*'] || row['Requester Name'] || '';
        const requesterEmail = row['Requester Email*'] || row['Requester Email'] || '';
        if (!title || !requesterName || !requesterEmail) { results.errors.push(`Row ${i + 2}: Missing required fields (Title, Requester Name, Requester Email)`); continue; }
        await db.iLLRequest.create({
          data: { title, author: row['Author'] || '', journal: row['Journal'] || '', year: row['Year'] || '', requesterName, requesterEmail, department: row['Department'] || '', status: row['Status (Pending/Processing/Fulfilled/Rejected)'] || row['Status'] || 'Pending', remarks: row['Remarks'] || '' },
        });
        results.success++;
      }
      return NextResponse.json({ message: `Imported ${results.success} ILL requests successfully`, ...results });
    }

    return NextResponse.json({ error: 'Invalid type. Use books, members, events, ebooks, faqs, staff, donors, new-arrivals, eresources, notices, ask-librarian, faculty-publications, past-papers, library-rules, photo-gallery, newsletters, committee, research-guides, cas-alerts, or ill-requests' }, { status: 400 });
  } catch (error) {
    console.error('Excel POST error:', error);
    return NextResponse.json({ error: 'Failed to process Excel file' }, { status: 500 });
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────

function xlsxResponse(wb: XLSX.WorkBook, filename: string) {
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  return new NextResponse(buf, {
    headers: {
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': `attachment; filename=${filename}`,
    },
  });
}

function fmtDate(d: Date): string {
  try { return d.toISOString().split('T')[0]; } catch { return ''; }
}
