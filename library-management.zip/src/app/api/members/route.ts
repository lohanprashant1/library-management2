import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/members
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const status = searchParams.get('status') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { email: { contains: search } },
        { phone: { contains: search } },
        { memberId: { contains: search } },
      ];
    }
    if (status) where.status = status;

    const [members, total] = await Promise.all([
      db.member.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.member.count({ where }),
    ]);

    return NextResponse.json({ members, total, page, limit });
  } catch (error) {
    console.error('Members GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch members' }, { status: 500 });
  }
}

// POST /api/members - Register new member
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // Check if email already exists
    const existingEmail = await db.member.findUnique({ where: { email: body.email } });
    if (existingEmail) {
      return NextResponse.json({ error: 'A member with this email already exists' }, { status: 409 });
    }

    // Generate member ID
    const count = await db.member.count();
    const memberId = `LIB-${String(count + 1).padStart(5, '0')}`;

    // Calculate expiry date (1 year from now)
    const expiryDate = new Date();
    expiryDate.setFullYear(expiryDate.getFullYear() + 1);

    const member = await db.member.create({
      data: {
        memberId,
        name: body.name,
        email: body.email,
        phone: body.phone,
        address: body.address || '',
        dateOfBirth: body.dateOfBirth || '',
        gender: body.gender || 'Other',
        occupation: body.occupation || '',
        photo: body.photo || '',
        status: 'Active',
        expiryDate,
      },
    });

    return NextResponse.json(member, { status: 201 });
  } catch (error) {
    console.error('Members POST error:', error);
    return NextResponse.json({ error: 'Failed to register member' }, { status: 500 });
  }
}

// PUT /api/members
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'Member ID is required' }, { status: 400 });
    }

    const existing = await db.member.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Member not found' }, { status: 404 });
    }

    const member = await db.member.update({
      where: { id },
      data: {
        name: data.name ?? undefined,
        email: data.email ?? undefined,
        phone: data.phone ?? undefined,
        address: data.address ?? undefined,
        dateOfBirth: data.dateOfBirth ?? undefined,
        gender: data.gender ?? undefined,
        occupation: data.occupation ?? undefined,
        photo: data.photo ?? undefined,
        status: data.status ?? undefined,
        expiryDate: data.expiryDate ?? undefined,
      },
    });

    return NextResponse.json(member);
  } catch (error) {
    console.error('Members PUT error:', error);
    return NextResponse.json({ error: 'Failed to update member' }, { status: 500 });
  }
}

// DELETE /api/members?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'Member ID is required' }, { status: 400 });
    }

    // Check for active transactions
    const activeTransactions = await db.transaction.count({
      where: { memberId: id, status: 'Issued' },
    });

    if (activeTransactions > 0) {
      return NextResponse.json(
        { error: 'Cannot delete member with active book issues. Return all books first.' },
        { status: 400 }
      );
    }

    await db.member.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Members DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete member' }, { status: 500 });
  }
}
