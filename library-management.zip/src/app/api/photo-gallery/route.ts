import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/photo-gallery
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const event = searchParams.get('event') || '';
    const isActive = searchParams.get('isActive');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
        { event: { contains: search } },
      ];
    }
    if (event) where.event = event;
    if (isActive !== null && isActive !== undefined && isActive !== '') {
      where.isActive = isActive === 'true';
    }

    const [items, total] = await Promise.all([
      db.photoGallery.findMany({
        where,
        orderBy: { sortOrder: 'asc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.photoGallery.count({ where }),
    ]);

    return NextResponse.json({ items, total, page, limit });
  } catch (error) {
    console.error('Photo Gallery GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch photos' }, { status: 500 });
  }
}

// POST /api/photo-gallery
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const photoGallery = await db.photoGallery.create({
      data: {
        title: body.title,
        description: body.description,
        image: body.image,
        event: body.event,
        date: body.date ? new Date(body.date) : undefined,
        sortOrder: body.sortOrder || 0,
        isActive: body.isActive ?? true,
      },
    });
    return NextResponse.json(photoGallery, { status: 201 });
  } catch (error) {
    console.error('Photo Gallery POST error:', error);
    return NextResponse.json({ error: 'Failed to create photo' }, { status: 500 });
  }
}

// PUT /api/photo-gallery
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'Photo ID is required' }, { status: 400 });
    }

    const existing = await db.photoGallery.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Photo not found' }, { status: 404 });
    }

    const photoGallery = await db.photoGallery.update({
      where: { id },
      data: {
        title: data.title ?? undefined,
        description: data.description ?? undefined,
        image: data.image ?? undefined,
        event: data.event ?? undefined,
        date: data.date ? new Date(data.date) : undefined,
        sortOrder: data.sortOrder ?? undefined,
        isActive: data.isActive ?? undefined,
      },
    });
    return NextResponse.json(photoGallery);
  } catch (error) {
    console.error('Photo Gallery PUT error:', error);
    return NextResponse.json({ error: 'Failed to update photo' }, { status: 500 });
  }
}

// DELETE /api/photo-gallery?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'Photo ID is required' }, { status: 400 });
    }

    await db.photoGallery.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Photo Gallery DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete photo' }, { status: 500 });
  }
}
