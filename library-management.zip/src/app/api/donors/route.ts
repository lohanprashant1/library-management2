import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/donors
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const donorType = searchParams.get('donorType') || '';
    const isFeatured = searchParams.get('isFeatured');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { designation: { contains: search } },
        { organization: { contains: search } },
        { description: { contains: search } },
      ];
    }
    if (donorType) where.donorType = donorType;
    if (isFeatured !== null && isFeatured !== undefined && isFeatured !== '') {
      where.isFeatured = isFeatured === 'true';
    }

    const [items, total] = await Promise.all([
      db.donor.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.donor.count({ where }),
    ]);

    return NextResponse.json({ items, total, page, limit });
  } catch (error) {
    console.error('Donors GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch donors' }, { status: 500 });
  }
}

// POST /api/donors
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const donor = await db.donor.create({
      data: {
        name: body.name,
        designation: body.designation,
        organization: body.organization,
        amount: body.amount,
        year: body.year,
        description: body.description,
        photo: body.photo,
        donorType: body.donorType || 'Individual',
        isFeatured: body.isFeatured ?? false,
      },
    });
    return NextResponse.json(donor, { status: 201 });
  } catch (error) {
    console.error('Donors POST error:', error);
    return NextResponse.json({ error: 'Failed to create donor' }, { status: 500 });
  }
}

// PUT /api/donors
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'Donor ID is required' }, { status: 400 });
    }

    const existing = await db.donor.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Donor not found' }, { status: 404 });
    }

    const donor = await db.donor.update({
      where: { id },
      data: {
        name: data.name ?? undefined,
        designation: data.designation ?? undefined,
        organization: data.organization ?? undefined,
        amount: data.amount ?? undefined,
        year: data.year ?? undefined,
        description: data.description ?? undefined,
        photo: data.photo ?? undefined,
        donorType: data.donorType ?? undefined,
        isFeatured: data.isFeatured ?? undefined,
      },
    });
    return NextResponse.json(donor);
  } catch (error) {
    console.error('Donors PUT error:', error);
    return NextResponse.json({ error: 'Failed to update donor' }, { status: 500 });
  }
}

// DELETE /api/donors?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'Donor ID is required' }, { status: 400 });
    }

    await db.donor.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Donors DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete donor' }, { status: 500 });
  }
}
