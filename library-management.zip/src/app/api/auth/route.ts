import { db } from '@/lib/db';
import { createHash } from 'crypto';
import { NextRequest, NextResponse } from 'next/server';

function hashPassword(password: string): string {
  return createHash('sha256').update(password).digest('hex');
}

// POST /api/auth
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { username, password } = body;

    if (!username || !password) {
      return NextResponse.json({ error: 'Username and password are required' }, { status: 400 });
    }

    const admin = await db.admin.findUnique({ where: { username } });

    if (!admin) {
      return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
    }

    const inputHash = hashPassword(password);
    if (inputHash !== admin.password) {
      return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
    }

    // Create a session token
    const sessionToken = Buffer.from(`${admin.id}:${Date.now()}`).toString('base64');

    return NextResponse.json({
      success: true,
      admin: {
        id: admin.id,
        username: admin.username,
        name: admin.name,
      },
      token: sessionToken,
    });
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json({ error: 'Login failed' }, { status: 500 });
  }
}

// GET /api/auth - health check
export async function GET() {
  return NextResponse.json({ status: 'auth endpoint ready' });
}
