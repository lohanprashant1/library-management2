import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/past-papers
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const department = searchParams.get('department') || '';
    const courseCode = searchParams.get('courseCode') || '';
    const year = searchParams.get('year') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { course: { contains: search } },
        { courseCode: { contains: search } },
      ];
    }
    if (department) where.department = department;
    if (courseCode) where.courseCode = courseCode;
    if (year) where.year = year;

    const [items, total] = await Promise.all([
      db.pastPaper.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.pastPaper.count({ where }),
    ]);

    return NextResponse.json({ items, total, page, limit });
  } catch (error) {
    console.error('Past Papers GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch past papers' }, { status: 500 });
  }
}

// POST /api/past-papers
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const pastPaper = await db.pastPaper.create({
      data: {
        title: body.title,
        course: body.course,
        courseCode: body.courseCode,
        department: body.department,
        year: body.year,
        semester: body.semester,
        fileUrl: body.fileUrl,
      },
    });
    return NextResponse.json(pastPaper, { status: 201 });
  } catch (error) {
    console.error('Past Papers POST error:', error);
    return NextResponse.json({ error: 'Failed to create past paper' }, { status: 500 });
  }
}

// PUT /api/past-papers
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'Past Paper ID is required' }, { status: 400 });
    }

    const existing = await db.pastPaper.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Past Paper not found' }, { status: 404 });
    }

    const pastPaper = await db.pastPaper.update({
      where: { id },
      data: {
        title: data.title ?? undefined,
        course: data.course ?? undefined,
        courseCode: data.courseCode ?? undefined,
        department: data.department ?? undefined,
        year: data.year ?? undefined,
        semester: data.semester ?? undefined,
        fileUrl: data.fileUrl ?? undefined,
      },
    });
    return NextResponse.json(pastPaper);
  } catch (error) {
    console.error('Past Papers PUT error:', error);
    return NextResponse.json({ error: 'Failed to update past paper' }, { status: 500 });
  }
}

// DELETE /api/past-papers?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'Past Paper ID is required' }, { status: 400 });
    }

    await db.pastPaper.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Past Papers DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete past paper' }, { status: 500 });
  }
}
