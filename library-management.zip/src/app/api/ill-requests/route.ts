import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/ill-requests
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const department = searchParams.get('department') || '';
    const status = searchParams.get('status') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { author: { contains: search } },
        { journal: { contains: search } },
        { requesterName: { contains: search } },
        { requesterEmail: { contains: search } },
      ];
    }
    if (department) where.department = department;
    if (status) where.status = status;

    const [items, total] = await Promise.all([
      db.iLLRequest.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.iLLRequest.count({ where }),
    ]);

    return NextResponse.json({ items, total, page, limit });
  } catch (error) {
    console.error('ILL Requests GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch ILL requests' }, { status: 500 });
  }
}

// POST /api/ill-requests
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const iLLRequest = await db.iLLRequest.create({
      data: {
        title: body.title,
        author: body.author,
        journal: body.journal,
        year: body.year,
        requesterName: body.requesterName,
        requesterEmail: body.requesterEmail,
        department: body.department,
        status: body.status || 'Pending',
        remarks: body.remarks,
      },
    });
    return NextResponse.json(iLLRequest, { status: 201 });
  } catch (error) {
    console.error('ILL Requests POST error:', error);
    return NextResponse.json({ error: 'Failed to create ILL request' }, { status: 500 });
  }
}

// PUT /api/ill-requests
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'ILL Request ID is required' }, { status: 400 });
    }

    const existing = await db.iLLRequest.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'ILL Request not found' }, { status: 404 });
    }

    const iLLRequest = await db.iLLRequest.update({
      where: { id },
      data: {
        title: data.title ?? undefined,
        author: data.author ?? undefined,
        journal: data.journal ?? undefined,
        year: data.year ?? undefined,
        requesterName: data.requesterName ?? undefined,
        requesterEmail: data.requesterEmail ?? undefined,
        department: data.department ?? undefined,
        status: data.status ?? undefined,
        remarks: data.remarks ?? undefined,
      },
    });
    return NextResponse.json(iLLRequest);
  } catch (error) {
    console.error('ILL Requests PUT error:', error);
    return NextResponse.json({ error: 'Failed to update ILL request' }, { status: 500 });
  }
}

// DELETE /api/ill-requests?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'ILL Request ID is required' }, { status: 400 });
    }

    await db.iLLRequest.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('ILL Requests DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete ILL request' }, { status: 500 });
  }
}
