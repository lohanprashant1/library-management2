import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/faqs
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const category = searchParams.get('category') || '';
    const isActive = searchParams.get('isActive');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { question: { contains: search } },
        { answer: { contains: search } },
      ];
    }
    if (category) where.category = category;
    if (isActive !== null && isActive !== undefined && isActive !== '') {
      where.isActive = isActive === 'true';
    }

    const [items, total] = await Promise.all([
      db.fAQ.findMany({
        where,
        orderBy: { sortOrder: 'asc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.fAQ.count({ where }),
    ]);

    return NextResponse.json({ items, total, page, limit });
  } catch (error) {
    console.error('FAQs GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch faqs' }, { status: 500 });
  }
}

// POST /api/faqs
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const faq = await db.fAQ.create({
      data: {
        question: body.question,
        answer: body.answer,
        category: body.category || 'General',
        sortOrder: body.sortOrder || 0,
        isActive: body.isActive ?? true,
      },
    });
    return NextResponse.json(faq, { status: 201 });
  } catch (error) {
    console.error('FAQs POST error:', error);
    return NextResponse.json({ error: 'Failed to create faq' }, { status: 500 });
  }
}

// PUT /api/faqs
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'FAQ ID is required' }, { status: 400 });
    }

    const existing = await db.fAQ.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'FAQ not found' }, { status: 404 });
    }

    const faq = await db.fAQ.update({
      where: { id },
      data: {
        question: data.question ?? undefined,
        answer: data.answer ?? undefined,
        category: data.category ?? undefined,
        sortOrder: data.sortOrder ?? undefined,
        isActive: data.isActive ?? undefined,
      },
    });
    return NextResponse.json(faq);
  } catch (error) {
    console.error('FAQs PUT error:', error);
    return NextResponse.json({ error: 'Failed to update faq' }, { status: 500 });
  }
}

// DELETE /api/faqs?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'FAQ ID is required' }, { status: 400 });
    }

    await db.fAQ.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('FAQs DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete faq' }, { status: 500 });
  }
}
