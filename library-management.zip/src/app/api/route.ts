import { NextResponse } from "next/server";
import { execSync } from "child_process";
import { existsSync } from "fs";
import { join } from "path";

export async function GET() {
  return NextResponse.json({ message: "Hello, world!" });
}

export async function POST() {
  try {
    const projectDir = process.cwd();
    const zipPath = join(projectDir, "download", "library-management.zip");

    // Check if zip already exists
    if (existsSync(zipPath)) {
      const fileBuffer = require("fs").readFileSync(zipPath);
      return new NextResponse(fileBuffer, {
        status: 200,
        headers: {
          "Content-Type": "application/zip",
          "Content-Disposition": "attachment; filename=library-management.zip",
          "Content-Length": String(fileBuffer.length),
        },
      });
    }

    // Generate zip on the fly
    execSync(
      `cd "${projectDir}" && mkdir -p download && zip -r download/library-management.zip prisma/ src/ public/ db/.gitkeep .env.example .gitignore package.json next.config.ts tsconfig.json tailwind.config.ts postcss.config.mjs eslint.config.mjs render.yaml bun.lock components.json -x "*.db" "node_modules/*" ".next/*"`,
      { timeout: 30000 }
    );

    const fileBuffer = require("fs").readFileSync(zipPath);
    return new NextResponse(fileBuffer, {
      status: 200,
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": "attachment; filename=library-management.zip",
        "Content-Length": String(fileBuffer.length),
      },
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
