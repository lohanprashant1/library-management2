'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Star, Send, CheckCircle2, Loader2, MessageSquareText } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';

export default function FeedbackPage() {
  const [form, setForm] = useState({
    name: '',
    email: '',
    message: '',
  });
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message || rating === 0) {
      setError('Please fill in all fields and provide a rating.');
      return;
    }
    setError('');
    setSubmitting(true);
    try {
      const res = await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, rating }),
      });
      if (res.ok) {
        setSuccess(true);
        setForm({ name: '', email: '', message: '' });
        setRating(0);
      } else {
        setError('Failed to submit feedback. Please try again.');
      }
    } catch {
      setError('Network error. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const ratingLabels = ['', 'Poor', 'Fair', 'Good', 'Very Good', 'Excellent'];

  if (success) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-8 sm:px-6 sm:py-12 lg:px-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col items-center justify-center py-16"
        >
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-50 text-emerald-600">
            <CheckCircle2 className="h-9 w-9" />
          </div>
          <h2 className="text-xl font-bold text-[#161922] sm:text-2xl">Thank You!</h2>
          <p className="mt-2 max-w-sm text-center text-sm text-[#161922]/50">
            Your feedback has been submitted successfully. We appreciate your input to help us improve our services.
          </p>
          <Button
            onClick={() => setSuccess(false)}
            className="mt-6 bg-[#C62729] text-white shadow-sm hover:bg-[#B32023]"
          >
            Submit More Feedback
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-8 sm:px-6 sm:py-12 lg:px-8">
      {/* Page Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-8 text-center"
      >
        <MessageSquareText className="mx-auto mb-3 h-10 w-10 text-[#C62729]" />
        <h1 className="text-2xl font-bold text-[#161922] sm:text-3xl">Share Your Feedback</h1>
        <p className="mt-2 text-sm text-[#161922]/50">
          We value your opinion. Help us serve you better by sharing your experience
        </p>
      </motion.div>

      {/* Form */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.1 }}
      >
        <Card className="border-slate-100 shadow-sm">
          <CardContent className="p-5 sm:p-8">
            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Star Rating */}
              <div className="space-y-2">
                <Label className="text-sm font-medium text-[#161922]">
                  Your Rating <span className="text-[#C62729]">*</span>
                </Label>
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      onMouseEnter={() => setHoverRating(star)}
                      onMouseLeave={() => setHoverRating(0)}
                      className="transition-transform hover:scale-110 focus:outline-none"
                      aria-label={`Rate ${star} star${star > 1 ? 's' : ''}`}
                    >
                      <Star
                        className={`h-8 w-8 transition-colors ${
                          star <= (hoverRating || rating)
                            ? 'fill-[#CB8B00] text-[#CB8B00]'
                            : 'fill-slate-100 text-slate-300'
                        }`}
                      />
                    </button>
                  ))}
                  {(hoverRating || rating) > 0 && (
                    <span className="ml-2 text-sm font-medium text-[#CB8B00]">
                      {ratingLabels[hoverRating || rating]}
                    </span>
                  )}
                </div>
              </div>

              {/* Name & Email */}
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-sm font-medium text-[#161922]">
                    Name <span className="text-[#C62729]">*</span>
                  </Label>
                  <Input
                    id="name"
                    name="name"
                    value={form.name}
                    onChange={handleChange}
                    placeholder="Enter your name"
                    required
                    className="border-slate-200 focus-visible:ring-[#C62729]/20 focus-visible:border-[#C62729]"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-medium text-[#161922]">
                    Email <span className="text-[#C62729]">*</span>
                  </Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={form.email}
                    onChange={handleChange}
                    placeholder="Enter your email"
                    required
                    className="border-slate-200 focus-visible:ring-[#C62729]/20 focus-visible:border-[#C62729]"
                  />
                </div>
              </div>

              {/* Message */}
              <div className="space-y-2">
                <Label htmlFor="message" className="text-sm font-medium text-[#161922]">
                  Your Message <span className="text-[#C62729]">*</span>
                </Label>
                <Textarea
                  id="message"
                  name="message"
                  value={form.message}
                  onChange={handleChange}
                  placeholder="Tell us about your experience..."
                  rows={4}
                  required
                  className="border-slate-200 focus-visible:ring-[#C62729]/20 focus-visible:border-[#C62729] resize-none"
                />
              </div>

              {/* Error */}
              {error && (
                <p className="text-xs text-[#C62729]">{error}</p>
              )}

              {/* Submit */}
              <Button
                type="submit"
                disabled={submitting}
                className="w-full bg-[#C62729] text-white shadow-sm hover:bg-[#B32023] disabled:opacity-60"
              >
                {submitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" />
                    Submit Feedback
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
