import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/ebooks
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const category = searchParams.get('category') || '';
    const format = searchParams.get('format') || '';
    const accessLevel = searchParams.get('accessLevel') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { author: { contains: search } },
        { description: { contains: search } },
        { isbn: { contains: search } },
        { publisher: { contains: search } },
      ];
    }
    if (category) where.category = category;
    if (format) where.format = format;
    if (accessLevel) where.accessLevel = accessLevel;

    const [items, total] = await Promise.all([
      db.eBook.findMany({
        where,
        orderBy: { addedAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.eBook.count({ where }),
    ]);

    return NextResponse.json({ items, total, page, limit });
  } catch (error) {
    console.error('EBooks GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch ebooks' }, { status: 500 });
  }
}

// POST /api/ebooks
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const ebook = await db.eBook.create({
      data: {
        title: body.title,
        author: body.author || '',
        description: body.description || '',
        category: body.category || '',
        isbn: body.isbn || '',
        publisher: body.publisher || '',
        fileUrl: body.fileUrl || '',
        fileSize: body.fileSize || '',
        format: body.format || 'PDF',
        accessLevel: body.accessLevel || 'All',
      },
    });
    return NextResponse.json(ebook, { status: 201 });
  } catch (error) {
    console.error('EBooks POST error:', error);
    return NextResponse.json({ error: 'Failed to create ebook' }, { status: 500 });
  }
}

// PUT /api/ebooks
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'EBook ID is required' }, { status: 400 });
    }

    const existing = await db.eBook.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'EBook not found' }, { status: 404 });
    }

    const ebook = await db.eBook.update({
      where: { id },
      data: {
        title: data.title ?? undefined,
        author: data.author ?? undefined,
        description: data.description ?? undefined,
        category: data.category ?? undefined,
        isbn: data.isbn ?? undefined,
        publisher: data.publisher ?? undefined,
        fileUrl: data.fileUrl ?? undefined,
        fileSize: data.fileSize ?? undefined,
        format: data.format ?? undefined,
        accessLevel: data.accessLevel ?? undefined,
      },
    });
    return NextResponse.json(ebook);
  } catch (error) {
    console.error('EBooks PUT error:', error);
    return NextResponse.json({ error: 'Failed to update ebook' }, { status: 500 });
  }
}

// DELETE /api/ebooks?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'EBook ID is required' }, { status: 400 });
    }

    await db.eBook.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('EBooks DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete ebook' }, { status: 500 });
  }
}
