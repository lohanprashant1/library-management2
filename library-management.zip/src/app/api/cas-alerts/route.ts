import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/cas-alerts
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const category = searchParams.get('category') || '';
    const isActive = searchParams.get('isActive');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
        { source: { contains: search } },
      ];
    }
    if (category) where.category = category;
    if (isActive !== null && isActive !== undefined && isActive !== '') {
      where.isActive = isActive === 'true';
    }

    const [items, total] = await Promise.all([
      db.cASAlert.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.cASAlert.count({ where }),
    ]);

    return NextResponse.json({ items, total, page, limit });
  } catch (error) {
    console.error('CAS Alerts GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch CAS alerts' }, { status: 500 });
  }
}

// POST /api/cas-alerts
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const cASAlert = await db.cASAlert.create({
      data: {
        title: body.title,
        description: body.description,
        category: body.category,
        alertDate: body.alertDate ? new Date(body.alertDate) : undefined,
        source: body.source,
        url: body.url,
        isActive: body.isActive ?? true,
      },
    });
    return NextResponse.json(cASAlert, { status: 201 });
  } catch (error) {
    console.error('CAS Alerts POST error:', error);
    return NextResponse.json({ error: 'Failed to create CAS alert' }, { status: 500 });
  }
}

// PUT /api/cas-alerts
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'CAS Alert ID is required' }, { status: 400 });
    }

    const existing = await db.cASAlert.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'CAS Alert not found' }, { status: 404 });
    }

    const cASAlert = await db.cASAlert.update({
      where: { id },
      data: {
        title: data.title ?? undefined,
        description: data.description ?? undefined,
        category: data.category ?? undefined,
        alertDate: data.alertDate ? new Date(data.alertDate) : undefined,
        source: data.source ?? undefined,
        url: data.url ?? undefined,
        isActive: data.isActive ?? undefined,
      },
    });
    return NextResponse.json(cASAlert);
  } catch (error) {
    console.error('CAS Alerts PUT error:', error);
    return NextResponse.json({ error: 'Failed to update CAS alert' }, { status: 500 });
  }
}

// DELETE /api/cas-alerts?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'CAS Alert ID is required' }, { status: 400 });
    }

    await db.cASAlert.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('CAS Alerts DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete CAS alert' }, { status: 500 });
  }
}
