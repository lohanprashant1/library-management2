import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

// GET /api/ask-librarian
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const search = searchParams.get('search') || '';
    const category = searchParams.get('category') || '';
    const status = searchParams.get('status') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { question: { contains: search } },
        { answer: { contains: search } },
        { name: { contains: search } },
        { email: { contains: search } },
      ];
    }
    if (category) where.category = category;
    if (status) where.status = status;

    const [items, total] = await Promise.all([
      db.askLibrarian.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.askLibrarian.count({ where }),
    ]);

    return NextResponse.json({ items, total, page, limit });
  } catch (error) {
    console.error('Ask Librarian GET error:', error);
    return NextResponse.json({ error: 'Failed to fetch questions' }, { status: 500 });
  }
}

// POST /api/ask-librarian
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const askLibrarian = await db.askLibrarian.create({
      data: {
        question: body.question,
        answer: body.answer,
        name: body.name,
        email: body.email,
        category: body.category || 'General',
        status: body.status || 'Pending',
      },
    });
    return NextResponse.json(askLibrarian, { status: 201 });
  } catch (error) {
    console.error('Ask Librarian POST error:', error);
    return NextResponse.json({ error: 'Failed to create question' }, { status: 500 });
  }
}

// PUT /api/ask-librarian
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ error: 'Question ID is required' }, { status: 400 });
    }

    const existing = await db.askLibrarian.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Question not found' }, { status: 404 });
    }

    const askLibrarian = await db.askLibrarian.update({
      where: { id },
      data: {
        question: data.question ?? undefined,
        answer: data.answer ?? undefined,
        name: data.name ?? undefined,
        email: data.email ?? undefined,
        category: data.category ?? undefined,
        status: data.status ?? undefined,
      },
    });
    return NextResponse.json(askLibrarian);
  } catch (error) {
    console.error('Ask Librarian PUT error:', error);
    return NextResponse.json({ error: 'Failed to update question' }, { status: 500 });
  }
}

// DELETE /api/ask-librarian?id=xxx
export async function DELETE(request: NextRequest) {
  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id) {
      return NextResponse.json({ error: 'Question ID is required' }, { status: 400 });
    }

    await db.askLibrarian.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Ask Librarian DELETE error:', error);
    return NextResponse.json({ error: 'Failed to delete question' }, { status: 500 });
  }
}
